library(knitr)
library(kableExtra)
library(dplyr)
bmi.bmi <- read.table("./Identity/BMI-BMI.sigma.txt", sep = "\t", header = T, row.names = NULL)[-1]
bmi.bmi <- bmi.bmi %>%
  arrange(method, pval)
bmi.bmi.table <- data.frame(pval = c(paste0("",5*10^seq(-8,-3,1),""), "0.050", "1.000"),
                            numbers = unique(bmi.bmi$numbers),
                            ivstrength = sprintf("%.3f", unique(bmi.bmi$ivstrength)),
                            id.exposure = "ukb-b-19953",
                            id.outcome = "ieu-a-2",
                            divw = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "DIVW")$beta-1.96*subset(bmi.bmi, method == "DIVW")$se > 1|
                                                                          subset(bmi.bmi, method == "DIVW")$beta+1.96*subset(bmi.bmi, method == "DIVW")$se < 1, T, F),
                                             format = "latex"),
                            mregger = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$beta),
                                                       "(",
                                                       sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$se),
                                                       ")"), bold = ifelse(subset(bmi.bmi, method == "MR-Egger")$beta-1.96*subset(bmi.bmi, method == "MR-Egger")$se > 1|
                                                                             subset(bmi.bmi, method == "MR-Egger")$beta+1.96*subset(bmi.bmi, method == "MR-Egger")$se < 1, T, F),
                                                format = "latex"),
                            wme = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "WME")$beta),
                                                       "(",
                                                       sprintf("%.3f",subset(bmi.bmi, method == "WME")$se),
                                                       ")"), bold = ifelse(subset(bmi.bmi, method == "WME")$beta-1.96*subset(bmi.bmi, method == "WME")$se > 1|
                                                                             subset(bmi.bmi, method == "WME")$beta+1.96*subset(bmi.bmi, method == "WME")$se < 1, T, F),
                                                format = "latex"),
                            aps = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "APS")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "APS")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "APS")$beta-1.96*subset(bmi.bmi, method == "APS")$se > 1|
                                                                          subset(bmi.bmi, method == "APS")$beta+1.96*subset(bmi.bmi, method == "APS")$se < 1, T, F),
                                             format = "latex"),
                            cml = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "cML-MA-BIC")$beta-1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se > 1|
                                                                         subset(bmi.bmi, method == "cML-MA-BIC")$beta+1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se < 1, T, F),
                                            format = "latex"),
                            apss = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$beta),
                                          "(",
                                          sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$se),
                                          ")"), bold = ifelse(subset(bmi.bmi, method == "MR-APSS")$beta-1.96*subset(bmi.bmi, method == "MR-APSS")$se > 1|
                                                                subset(bmi.bmi, method == "MR-APSS")$beta+1.96*subset(bmi.bmi, method == "MR-APSS")$se < 1, T, F),
                                          format = "latex"),
                            gmm = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "MR-GMM")$beta-1.96*subset(bmi.bmi, method == "MR-GMM")$se > 1|
                                                                         subset(bmi.bmi, method == "MR-GMM")$beta+1.96*subset(bmi.bmi, method == "MR-GMM")$se < 1, T, F),
                                            format = "latex"))
tab1 <- bmi.bmi.table[, 1:6]
tab2 <- bmi.bmi.table[, 7:12]
tab <- rbind(tab1, as.data.frame(rbind(c("MR-Egger", "WME", "APS", "cML-MA-BIC", "MR-APSS", "MR-GMM"))) |> 
               setNames(colnames(tab1)), tab2 |> 
               setNames(colnames(tab1)))
kbl(tab, booktabs = T, format = "latex", linesep = "", col.names = c("P", "\\# of IVs", "IV strength", "Exposure ID", "Outcome ID", "DIVW"), escape = F) %>%
  kable_styling(latex_options = c("scale_down","HOLD_position")) %>%
  row_spec(8, hline_after = T) %>%
  row_spec(9, hline_after = T)

bmi.bmi <- read.table("./Identity/BMI-BMI.pvalue.txt", sep = "\t", header = T, row.names = NULL)[-1]
bmi.bmi <- bmi.bmi %>%
  arrange(method, pval)
bmi.bmi.table <- data.frame(pval = c(paste0("",5*10^seq(-8,-3,1),""), "0.050", "1.000"),
                            numbers = unique(bmi.bmi$numbers),
                            ivstrength = sprintf("%.3f", unique(bmi.bmi$ivstrength)),
                            id.exposure = "ukb-b-19953",
                            id.outcome = "ieu-a-2",
                            divw = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "DIVW")$beta-1.96*subset(bmi.bmi, method == "DIVW")$se > 1|
                                                                          subset(bmi.bmi, method == "DIVW")$beta+1.96*subset(bmi.bmi, method == "DIVW")$se < 1, T, F),
                                             format = "latex"),
                            mregger = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$beta),
                                                       "(",
                                                       sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$se),
                                                       ")"), bold = ifelse(subset(bmi.bmi, method == "MR-Egger")$beta-1.96*subset(bmi.bmi, method == "MR-Egger")$se > 1|
                                                                             subset(bmi.bmi, method == "MR-Egger")$beta+1.96*subset(bmi.bmi, method == "MR-Egger")$se < 1, T, F),
                                                format = "latex"),
                            wme = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "WME")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "WME")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "WME")$beta-1.96*subset(bmi.bmi, method == "WME")$se > 1|
                                                                         subset(bmi.bmi, method == "WME")$beta+1.96*subset(bmi.bmi, method == "WME")$se < 1, T, F),
                                            format = "latex"),
                            aps = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "APS")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "APS")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "APS")$beta-1.96*subset(bmi.bmi, method == "APS")$se > 1|
                                                                         subset(bmi.bmi, method == "APS")$beta+1.96*subset(bmi.bmi, method == "APS")$se < 1, T, F),
                                            format = "latex"),
                            cml = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "cML-MA-BIC")$beta-1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se > 1|
                                                                         subset(bmi.bmi, method == "cML-MA-BIC")$beta+1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se < 1, T, F),
                                            format = "latex"),
                            apss = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "MR-APSS")$beta-1.96*subset(bmi.bmi, method == "MR-APSS")$se > 1|
                                                                          subset(bmi.bmi, method == "MR-APSS")$beta+1.96*subset(bmi.bmi, method == "MR-APSS")$se < 1, T, F),
                                             format = "latex"),
                            gmm = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "MR-GMM")$beta-1.96*subset(bmi.bmi, method == "MR-GMM")$se > 1|
                                                                         subset(bmi.bmi, method == "MR-GMM")$beta+1.96*subset(bmi.bmi, method == "MR-GMM")$se < 1, T, F),
                                            format = "latex"))
tab1 <- bmi.bmi.table[, 1:6]
tab2 <- bmi.bmi.table[, 7:12]
tab <- rbind(tab1, as.data.frame(rbind(c("MR-Egger", "WME", "APS", "cML-MA-BIC", "MR-APSS", "MR-GMM"))) |> 
               setNames(colnames(tab1)), tab2 |> 
               setNames(colnames(tab1)))
kbl(tab, booktabs = T, format = "latex", linesep = "", col.names = c("P", "\\# of IVs", "IV strength", "Exposure ID", "Outcome ID", "DIVW"), escape = F) %>%
  kable_styling(latex_options = c("scale_down","HOLD_position")) %>%
  row_spec(8, hline_after = T) %>%
  row_spec(9, hline_after = T)

bmi.bmi <- read.table("./Identity/HDL-HDL.sigma.txt", sep = "\t", header = T, row.names = NULL)[-1]
bmi.bmi <- bmi.bmi %>%
  arrange(method, pval)
bmi.bmi.table <- data.frame(pval = c(paste0("",5*10^seq(-8,-3,1),""), "0.050", "1.000"),
                            numbers = unique(bmi.bmi$numbers),
                            ivstrength = sprintf("%.3f", unique(bmi.bmi$ivstrength)),
                            id.exposure = "ieu-b-109",
                            id.outcome = "ebi-a-GCST002223",
                            divw = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "DIVW")$beta-1.96*subset(bmi.bmi, method == "DIVW")$se > 1|
                                                                          subset(bmi.bmi, method == "DIVW")$beta+1.96*subset(bmi.bmi, method == "DIVW")$se < 1, T, F),
                                             format = "latex"),
                            mregger = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$beta),
                                                       "(",
                                                       sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$se),
                                                       ")"), bold = ifelse(subset(bmi.bmi, method == "MR-Egger")$beta-1.96*subset(bmi.bmi, method == "MR-Egger")$se > 1|
                                                                             subset(bmi.bmi, method == "MR-Egger")$beta+1.96*subset(bmi.bmi, method == "MR-Egger")$se < 1, T, F),
                                                format = "latex"),
                            wme = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "WME")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "WME")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "WME")$beta-1.96*subset(bmi.bmi, method == "WME")$se > 1|
                                                                         subset(bmi.bmi, method == "WME")$beta+1.96*subset(bmi.bmi, method == "WME")$se < 1, T, F),
                                            format = "latex"),
                            aps = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "APS")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "APS")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "APS")$beta-1.96*subset(bmi.bmi, method == "APS")$se > 1|
                                                                         subset(bmi.bmi, method == "APS")$beta+1.96*subset(bmi.bmi, method == "APS")$se < 1, T, F),
                                            format = "latex"),
                            cml = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "cML-MA-BIC")$beta-1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se > 1|
                                                                         subset(bmi.bmi, method == "cML-MA-BIC")$beta+1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se < 1, T, F),
                                            format = "latex"),
                            apss = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "MR-APSS")$beta-1.96*subset(bmi.bmi, method == "MR-APSS")$se > 1|
                                                                          subset(bmi.bmi, method == "MR-APSS")$beta+1.96*subset(bmi.bmi, method == "MR-APSS")$se < 1, T, F),
                                             format = "latex"),
                            gmm = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "MR-GMM")$beta-1.96*subset(bmi.bmi, method == "MR-GMM")$se > 1|
                                                                         subset(bmi.bmi, method == "MR-GMM")$beta+1.96*subset(bmi.bmi, method == "MR-GMM")$se < 1, T, F),
                                            format = "latex"))
tab1 <- bmi.bmi.table[, 1:6]
tab2 <- bmi.bmi.table[, 7:12]
tab <- rbind(tab1, as.data.frame(rbind(c("MR-Egger", "WME", "APS", "cML-MA-BIC", "MR-APSS", "MR-GMM"))) |> 
               setNames(colnames(tab1)), tab2 |> 
               setNames(colnames(tab1)))
kbl(tab, booktabs = T, format = "latex", linesep = "", col.names = c("P", "\\# of IVs", "IV strength", "Exposure ID", "Outcome ID", "DIVW"), escape = F) %>%
  kable_styling(latex_options = c("scale_down","HOLD_position")) %>%
  row_spec(8, hline_after = T) %>%
  row_spec(9, hline_after = T)

bmi.bmi <- read.table("./Identity/HDL-HDL.pvalue.txt", sep = "\t", header = T, row.names = NULL)[-1]
bmi.bmi <- bmi.bmi %>%
  arrange(method, pval)
bmi.bmi.table <- data.frame(pval = c(paste0("",5*10^seq(-8,-3,1),""), "0.050", "1.000"),
                            numbers = unique(bmi.bmi$numbers),
                            ivstrength = sprintf("%.3f", unique(bmi.bmi$ivstrength)),
                            id.exposure = "ieu-b-109",
                            id.outcome = "ebi-a-GCST002223",
                            divw = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "DIVW")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "DIVW")$beta-1.96*subset(bmi.bmi, method == "DIVW")$se > 1|
                                                                          subset(bmi.bmi, method == "DIVW")$beta+1.96*subset(bmi.bmi, method == "DIVW")$se < 1, T, F),
                                             format = "latex"),
                            mregger = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$beta),
                                                       "(",
                                                       sprintf("%.3f",subset(bmi.bmi, method == "MR-Egger")$se),
                                                       ")"), bold = ifelse(subset(bmi.bmi, method == "MR-Egger")$beta-1.96*subset(bmi.bmi, method == "MR-Egger")$se > 1|
                                                                             subset(bmi.bmi, method == "MR-Egger")$beta+1.96*subset(bmi.bmi, method == "MR-Egger")$se < 1, T, F),
                                                format = "latex"),
                            wme = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "WME")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "WME")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "WME")$beta-1.96*subset(bmi.bmi, method == "WME")$se > 1|
                                                                         subset(bmi.bmi, method == "WME")$beta+1.96*subset(bmi.bmi, method == "WME")$se < 1, T, F),
                                            format = "latex"),
                            aps = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "APS")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "APS")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "APS")$beta-1.96*subset(bmi.bmi, method == "APS")$se > 1|
                                                                         subset(bmi.bmi, method == "APS")$beta+1.96*subset(bmi.bmi, method == "APS")$se < 1, T, F),
                                            format = "latex"),
                            cml = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "cML-MA-BIC")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "cML-MA-BIC")$beta-1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se > 1|
                                                                         subset(bmi.bmi, method == "cML-MA-BIC")$beta+1.96*subset(bmi.bmi, method == "cML-MA-BIC")$se < 1, T, F),
                                            format = "latex"),
                            apss = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$beta),
                                                    "(",
                                                    sprintf("%.3f",subset(bmi.bmi, method == "MR-APSS")$se),
                                                    ")"), bold = ifelse(subset(bmi.bmi, method == "MR-APSS")$beta-1.96*subset(bmi.bmi, method == "MR-APSS")$se > 1|
                                                                          subset(bmi.bmi, method == "MR-APSS")$beta+1.96*subset(bmi.bmi, method == "MR-APSS")$se < 1, T, F),
                                             format = "latex"),
                            gmm = cell_spec(paste0(sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$beta),
                                                   "(",
                                                   sprintf("%.3f",subset(bmi.bmi, method == "MR-GMM")$se),
                                                   ")"), bold = ifelse(subset(bmi.bmi, method == "MR-GMM")$beta-1.96*subset(bmi.bmi, method == "MR-GMM")$se > 1|
                                                                         subset(bmi.bmi, method == "MR-GMM")$beta+1.96*subset(bmi.bmi, method == "MR-GMM")$se < 1, T, F),
                                            format = "latex"))
tab1 <- bmi.bmi.table[, 1:6]
tab2 <- bmi.bmi.table[, 7:12]
tab <- rbind(tab1, as.data.frame(rbind(c("MR-Egger", "WME", "APS", "cML-MA-BIC", "MR-APSS", "MR-GMM"))) |> 
               setNames(colnames(tab1)), tab2 |> 
               setNames(colnames(tab1)))
kbl(tab, booktabs = T, format = "latex", linesep = "", col.names = c("P", "\\# of IVs", "IV strength", "Exposure ID", "Outcome ID", "DIVW"), escape = F) %>%
  kable_styling(latex_options = c("scale_down","HOLD_position")) %>%
  row_spec(8, hline_after = T) %>%
  row_spec(9, hline_after = T)


res_gmm <- read.table("./Negative0.05/mrgmm.txt", sep = "\t", quote = "", row.names = NULL, header = T)[, -1]
res_gmm$pvalue <- 10^(-res_gmm$log_pval)
res_gmm <- res_gmm[, -9]
kbl(res_gmm, booktabs = T,format = "latex", linesep = "", digits = 3,  col.names = c("Exposure ID", "Exposure", "Outcome ID", "Outcome",
                                                                       "\\# of IVs", "IV strength", "Estimate", "SE", "P-value")) %>%
  kable_styling(latex_options = c("scale_down", "HOLD_position"))


res_gmm <- readr::read_delim("AllResAnno.txt", delim = "\t")
res_gmm_original <- read.table("./Outcome0.05/mrgmm.txt", sep = "\t", quote = "", row.names = NULL, header = T)[, -1]
res_gmm_original <- res_gmm_original[!duplicated(res_gmm_original$exposure),]
res_gmm_merge <- merge(res_gmm, res_gmm_original, by = "id.exposure")
res_gmm_merge$pvalue <- 10^(-res_gmm_merge$Negative.log.p)
res_gmm_merge <- res_gmm_merge %>%
  arrange(Negative.log.p)
res_gmm_merge$k <- 1:nrow(res_gmm_merge)
res_gmm_sig <- res_gmm_merge[max(which(res_gmm_merge$pvalue > 0.05/(nrow(res_gmm_merge) + 1 - res_gmm_merge$k))):nrow(res_gmm_merge), ]
res_gmm_sig <- data.frame(res_gmm_sig$id.exposure,
                          res_gmm_sig$exposure.x,
                          "ieu-a-7",
                          "CHD",
                          res_gmm_sig$accession,
                          res_gmm_sig$symbol,
                          res_gmm_sig$IVnumber,
                          sprintf("%.3f", res_gmm_sig$IVstrength),
                          sprintf("%.3f", res_gmm_sig$estimate),
                          sprintf("%.3f", res_gmm_sig$se.x),
                          sprintf("%.3f", res_gmm_sig$pvalue))
res_gmm_sig <- res_gmm_sig %>%
  arrange(res_gmm_sig.id.exposure)
kbl(res_gmm_sig, booktabs = T,format = "latex", linesep = "", digits = 3,  col.names = c("Exposure ID", "Exposure", "Outcome ID", "Outcome", "Uniprot", "Symbol", "\\# of IVs", "IV strength", "Estimate", "SE", "P-value"), escape = F) %>%
  kable_styling(latex_options = c("scale_down", "hold_position"))
# tab1 <- res_gmm_sig[, 1:6]
# tab2 <- res_gmm_sig[, 7:12]
# tab <- rbind(tab1, as.data.frame(rbind(c("\\# of IVs", "IV strength", "Estimate", "SE", "P-value", " "))) |> 
#                setNames(colnames(tab1)), tab2 |> 
#                setNames(colnames(tab1)))
# kbl(tab, booktabs = T, digits = 3, longtable = T, format = "latex", linesep = "",
#     col.names = c("Exposure ID", "Exposure", "Outcome ID", "Outcome", "Uniprot", "Symbol"), escape = F) %>%
#   kable_styling(latex_options = c("HOLD_position")) %>%
#   row_spec(45, hline_after = T) %>%
#   row_spec(46, hline_after = T)
