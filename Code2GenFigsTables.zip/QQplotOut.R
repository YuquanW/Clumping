library(dplyr)
library(ggplot2)
library(ggpubr)
library(stringr)
library(httr)
library(httr2)
library(jsonlite)

library(disgenet2r)
library(clusterProfiler)
library(enrichplot)
library(DOSE)
library(igraph)
library(ggraph)
library(org.Hs.eg.db)

filelist <- c("divw.txt",
              "mregger.txt",
              "wme.txt",
              "raps.txt",
              "mrcml.txt",
              "mrapss.txt",
              "mrgmm.txt")
Method <- c("DIVW", "MR-Egger", "WME", "APS", "cML-MA-BIC","MR-APSS","MR-GMM")
prefix <- c("Outcome0.05/", "Outcome0.1/", "OutcomeTop50/", "OutcomeTop500/")
title <- paste("Threshold for IV selection:", 
               c("p-value < 0.05",
                 "p-value < 0.1",
                 "smallest 50 p-values",
                 "smallest 500 p-values"))
figname <- paste("fig5", c("a", "b", "c", "d"), ".png", sep = "")

for (j in 1:length(prefix)) {
  res <- NULL
  inflation <- NULL
  for (i in 1:length(filelist)) {
    res_i <- read.table(paste(prefix[j], filelist[i], sep = ""), sep = "\t", header = T, quote = "", row.names = NULL)[, -1]
    #res_i <- res_i[!duplicated(res_i$exposure), ]
    method <- Method[i]
    res_i <- res_i[!duplicated(res_i$exposure), ]
    exp.x <- -log10(rev(ppoints(nrow(res_i))))
    res <- rbind(res, data.frame(id.exposure = res_i$id.exposure[order(res_i$log_pval)],
                                 exposure = res_i$exposure[order(res_i$log_pval)],
                                 estimate = res_i$est[order(res_i$log_pval)],
                                 se = res_i$se[order(res_i$log_pval)],
                                 `Negative log p` = sort(res_i$log_pval),
                                 Theoretical = exp.x,
                                 Method = method,
                                 lower = rev(-log10(qbeta(0.975, seq_len(length(exp.x)), rev(seq_len(length(exp.x)))))),
                                 upper = rev(-log10(qbeta(0.025, seq_len(length(exp.x)), rev(seq_len(length(exp.x))))))))
    inflation <- rbind(inflation, data.frame(chisq = (res_i$est/res_i$se)^2,
                                             method = method))
  }
  res$Method <- factor(res$Method, levels = unique(res$Method))
  inflation$method <- factor(inflation$method, levels = unique(inflation$method))
  res <- res %>%
    mutate(Negative.log.p = pmin(Negative.log.p, 30))
  inflation <- inflation %>%
    group_by(method) %>%
    summarise(lambda_gc = median(chisq)/qchisq(0.5, 1))
  label <- list(substitute(lambda[DIVW] == value, list(value = sprintf("%.2f", inflation$lambda_gc[1]))),
                substitute(lambda[MR-Egger] == value, list(value = sprintf("%.2f", inflation$lambda_gc[2]))),
                substitute(lambda[WME] == value, list(value = sprintf("%.2f", inflation$lambda_gc[3]))),
                substitute(lambda[APS] == value, list(value = sprintf("%.2f", inflation$lambda_gc[4]))),
                substitute(lambda[cML-MA-BIC] == value, list(value = sprintf("%.2f", inflation$lambda_gc[5]))),
                substitute(lambda[MR-APSS] == value, list(value = sprintf("%.2f", inflation$lambda_gc[6]))),
                substitute(lambda[MR-GMM] == value, list(value = sprintf("%.2f", inflation$lambda_gc[7]))))
  inflation_text <- data.frame(x = 0, y = seq(30, length.out=7, by = -2),
                               label = unlist(Map(deparse, label)), 
                               method = factor(Method, levels = Method))
  p <- ggplot(aes(x = Theoretical, y = Negative.log.p, shape = Method, color = Method), data = res) + 
    geom_point(size = 4)+
    ylim(c(0, 30)) +
    geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed", linewidth = 1.5) +
    geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.1, show.legend = F) +
    theme_pubr(base_size = 22) +
    scale_shape_manual(values=seq(12,19)) +
    labs(subtitle = title[j],
         x = expression("Theoretical " * -log[10] *"p"),
         y = expression("Observed " * -log[10] * "p")) +
    theme(plot.subtitle = element_text(size = 18, face = "bold", hjust = 0.5)) +
    geom_text(aes(x = x, y = y, label = label, color = method), data = inflation_text,
              parse = T, hjust = 0, size = 7, show.legend = F)
  p <- ggpar(p, legend = "bottom")
  ggexport(p, filename = figname[j], width = 3000, height = 3000, res = 300)
  
}
j <- 1
res <- NULL
inflation <- NULL
for (i in 1:length(filelist)) {
  res_i <- read.table(paste(prefix[j], filelist[i], sep = ""), sep = "\t", header = T, quote = "", row.names = NULL)[, -1]
  #res_i <- res_i[!duplicated(res_i$exposure), ]
  method <- Method[i]
  res_i <- res_i[!duplicated(res_i$exposure), ]
  exp.x <- -log10(rev(ppoints(nrow(res_i))))
  res <- rbind(res, data.frame(id.exposure = res_i$id.exposure[order(res_i$log_pval)],
                               exposure = res_i$exposure[order(res_i$log_pval)],
                               estimate = res_i$est[order(res_i$log_pval)],
                               se = res_i$se[order(res_i$log_pval)],
                               `Negative log p` = sort(res_i$log_pval),
                               Theoretical = exp.x,
                               Method = method,
                               lower = rev(-log10(qbeta(0.975, seq_len(length(exp.x)), rev(seq_len(length(exp.x)))))),
                               upper = rev(-log10(qbeta(0.025, seq_len(length(exp.x)), rev(seq_len(length(exp.x))))))))
  inflation <- rbind(inflation, data.frame(chisq = (res_i$est/res_i$se)^2,
                                           method = method))
}
res_gmm <- subset(res, Method == "MR-GMM")
res_gmm$pvalue <- 10^(-res_gmm$Negative.log.p)
res_gmm$k <- 1:nrow(res_gmm)
res_gmm_sig <- res_gmm[max(which(res_gmm$pvalue > 0.05/(nrow(res_gmm) + 1 - res_gmm$k))):nrow(res_gmm), ]
#

res_gmm_sig <- read.table("SigResultsAnno.txt", sep = "\t", header = T)
res_gmm_sig_holm <- res_gmm[max(which(res_gmm$pvalue > 0.05/(nrow(res_gmm) + 1 - res_gmm$k))):nrow(res_gmm), ]
res_gmm_sig <- subset(res_gmm_sig, exposure %in% res_gmm_sig_holm$exposure)
genelist <- unlist(strsplit(res_gmm_sig$symbol, split = ";"))
write.table(data.frame(protein = res_gmm_sig$symbol, `log-zscore` = sign(res_gmm_sig$estimate)*log(abs(res_gmm_sig$estimate/res_gmm_sig$se))), "proteins.txt", sep = "\t", row.names = F, quote = F, col.names = F)

## PPI

# gene_id <- bitr(res_gmm_sig$symbol, fromType="SYMBOL", toType="ENTREZID", OrgDb="org.Hs.eg.db")
# #gene_id <- gene_id[!duplicated(gene_id$SYMBOL), ]
# 
# string_db <- STRINGdb$new( version="12.0", species=9606,
#                            score_threshold=200, network_type="full", link_data='combined_only', input_directory="")
# genes <- res_gmm_sig$symbol
# genes[which(str_detect(genes, ";"))] <- c("Laminin", "HSP90A", "SERF1")
# mapped <- string_db$map(data.frame(gene = genes, logzscore = sign(res_gmm_sig$estimate)*log(abs(res_gmm_sig$estimate/res_gmm_sig$se))), "gene", removeUnmappedRows = TRUE)
# mapped <- string_db$add_diff_exp_color(mapped, logFcColStr="logzscore")
# #write.table(data.frame(mapped$gene, mapped$color), "proteins.txt", sep = "\t", row.names = F, quote = F, col.names = F)
# hits <- mapped$STRING_id

#enrichment <- string_db$get_enrichment( hits )

## STRING PPI CLUSTER

#clustersList <- string_db$get_clusters(hits)
#string_db$plot_network(clustersList[[1]], payload_id = payload_id)


## OmniPath protein-drug interaction
# Sys.setenv("http_proxy" = "https://127.0.0.1:7897")
# interactions <- import_omnipath_interactions() %>% as_tibble()
# OPI_g <- interaction_graph(interactions = interactions )

## Enrichment Analysis
res_gmm$accession <- NA
res_gmm$recname <- NA
res_gmm$symbol <- NA
for (i in 1:nrow(res_gmm)) {
  protein_name <- res_gmm$exposure[i]
  base_url <- "https://rest.uniprot.org/uniprotkb/search"
  params <- list(
    query = paste0("protein_name:", str_replace_all(protein_name, " ", "+"),
                   " +AND+",
                   " taxonomy_id:9606 ",
                   "+AND+ reviewed:true"),
    fields = "accession,protein_name,gene_names",
    sort = "accession desc",
    size = "50"
  )
  req <- request(base_url)
  req |> req_headers(
    accept = "application/json"
  )
  req <- req |> req_url_query(!!!params)
  response <- GET(req$url, add_headers(Accept = "application/json"))
  
  # Parse the response content as JSON
  content <- content(response, "text")
  data <- fromJSON(content)
  if (length(data[["results"]])!=0) {
    for (j in 1:nrow(data[["results"]])) {
      if (!is.na(data[["results"]]$proteinDescription$recommendedName$fullName$value[[j]]) & 
          (tolower(protein_name)==tolower(data[["results"]]$proteinDescription$recommendedName$fullName$value[[j]]))) {
        res_gmm$accession[i] <- data[["results"]]$primaryAccession[j]
        res_gmm$recname[i] <- data[["results"]]$proteinDescription$recommendedName$fullName$value[[j]]
        if (length(data[["results"]]$genes[[j]]$geneName$value) > 1) {
          res_gmm$symbol[i] <- paste(data[["results"]]$genes[[j]]$geneName$value, collapse = ";")
        } else {
          res_gmm$symbol[i] <- data[["results"]]$genes[[j]]$geneName$value
        }
        break
      } else if (!is.null(data[["results"]]$proteinDescription$alternativeNames[[j]]) &
                 (tolower(protein_name) %in% tolower(data[["results"]]$proteinDescription$alternativeNames[[j]]$fullName$value))) {
        res_gmm$accession[i] <- data[["results"]]$primaryAccession[j]
        res_gmm$recname[i] <- data[["results"]]$proteinDescription$recommendedName$fullName$value[[j]]
        if (length(data[["results"]]$genes[[j]]$geneName$value) > 1) {
          res_gmm$symbol[i] <- paste(data[["results"]]$genes[[j]]$geneName$value, collapse = ";")
        } else {
          res_gmm$symbol[i] <- data[["results"]]$genes[[j]]$geneName$value
        }
        break
      }
    }
  }
  print(i)
}
query_miss <- which(is.na(res_gmm$symbol))
exposure_miss <- res_gmm$exposure[query_miss]
print(exposure_miss)
res_gmm$accession[query_miss] <- c("Q7Z5A8",
                                   "Q99075",
                                   NA,
                                   "Q9BQD7",
                                   "Q8WUY8",
                                   "P01375",
                                   "P55773",
                                   "P0DUB6",
                                   "P15692",
                                   "P07948-2",
                                   "Q01973",
                                   "Q9NTK1",
                                   NA,
                                   "C9JG98",
                                   "O60939",
                                   "P06850",
                                   NA,
                                   "P20396",
                                   "Q96LL9",
                                   "P04114",
                                   "Q9BYC5",
                                   "P04054",
                                   "P00742",
                                   "Q9Y2V2",
                                   NA,
                                   NA,
                                   "P61812",
                                   "O95461",
                                   NA,
                                   "Q6P4F1",
                                   "Q96D05",
                                   NA,
                                   "O95169",
                                   "Q6P4E1",
                                   "A2RU67",
                                   "O14944",
                                   "Q14005",
                                   NA,
                                   "P16860",
                                   "Q9NX62",
                                   "Q9H7B7",
                                   "P46933",
                                   "P01133",
                                   "P01258",
                                   "P01854",
                                   NA,
                                   "P38024",
                                   "P01602",
                                   "Q9H1K1",
                                   "E7ERP7",
                                   "Q96KW9",
                                   NA,
                                   NA,
                                   "Q14232",
                                   "Q6UXG2",
                                   NA,
                                   "Q15365",
                                   "Q8N3H0",
                                   "Q9UIF7",
                                   "P21217",
                                   "Q6PB30",
                                   NA,
                                   "Q96LT9",
                                   "P21128",
                                   "Q5VZY2",
                                   "P15692-9",
                                   "P01308",
                                   "A1A4F0",
                                   "Q9Y2A9",
                                   "P35590",
                                   "O60568",
                                   "A1L188",
                                   NA,
                                   "A8MWY0",
                                   "P49789",
                                   "Q96LR4",
                                   NA,
                                   NA,
                                   NA,
                                   "Q9H078",
                                   NA,
                                   "Q15078",
                                   "P35318",
                                   "Q6UX34",
                                   NA,
                                   "P48960",
                                   "Q5VVJ2",
                                   "O95990",
                                   "Q8WV74",
                                   "Q9P0R6",
                                   "Q9H741",
                                   "Q9NZK5",
                                   "P0DPI2",
                                   "Q15018",
                                   NA,
                                   "P08754",
                                   "P22736",
                                   "P62701",
                                   "P02775",
                                   NA,
                                   "P15428",
                                   NA,
                                   "Q15119",
                                   "Q9UPX6",
                                   NA,
                                   "P08294",
                                   "Q92838",
                                   "P16152",
                                   "Q15109",
                                   "P00747",
                                   "O95786",
                                   "Q9P286",
                                   "H0Y7L5",
                                   "Q9Y231",
                                   NA,
                                   NA,
                                   NA,
                                   "Q9UBP6",
                                   NA,
                                   "Q08499",
                                   "Q8TCD5",
                                   "Q96PH6",
                                   "Q06787",
                                   "P13591-3",
                                   NA,
                                   NA,
                                   NA,
                                   "P14550",
                                   "B0FP48",
                                   "O60504",
                                   "Q6ZMB0",
                                   "O43681",
                                   "Q13046",
                                   "Q8N0V5-3",
                                   "Q12904",
                                   "O95704",
                                   "Q15118",
                                   "Q15884",
                                   "Q8WWG1",
                                   "P05067",
                                   "P01135",
                                   NA,
                                   "Q92870",
                                   NA,
                                   NA,
                                   "Q9BWE0",
                                   "P16083",
                                   NA,
                                   "Q9BQ65",
                                   NA,
                                   "P10600",
                                   "Q9UJK0",
                                   "Q9UNQ2",
                                   NA,
                                   "Q9Y240",
                                   "P49959",
                                   "P09874",
                                   "P01275",
                                   "P0CG47",
                                   "Q8N6K0",
                                   "Q6B8I1",
                                   "Q92600",
                                   "P54750",
                                   "Q14432",
                                   "Q96ES7",
                                   NA,
                                   "Q9H7X2",
                                   "Q9H6L5",
                                   "Q96DF8",
                                   "Q8N5Y8",
                                   "P55075-2",
                                   "P52758",
                                   "P09668",
                                   "A6NKW6",
                                   "Q07954",
                                   "Q8IZ08",
                                   NA,
                                   "Q86Y97",
                                   NA,
                                   "Q99497",
                                   "Q6UX46",
                                   "P04070",
                                   "P05412",
                                   NA,
                                   "O43173",
                                   "Q9NX14",
                                   "P48023",
                                   NA,
                                   "Q16609",
                                   "P27695",
                                   "Q9BQG2",
                                   "Q6NW40",
                                   "P01137",
                                   "Q13356",
                                   "O75828",
                                   NA,
                                   "P01160",
                                   "O95671",
                                   "P55075-3",
                                   NA,
                                   "A1KZ92",
                                   "P19404",
                                   "P05771-2",
                                   "Q9NR21",
                                   "P39060",
                                   "P09848",
                                   "Q13976-2",
                                   "P01189",
                                   "Q11128",
                                   "Q9UHX1",
                                   "Q86UD5",
                                   NA,
                                   "Q02763",
                                   "Q9BRK3",
                                   "P61278",
                                   NA,
                                   "P20062",
                                   "Q9Y606",
                                   NA,
                                   "Q13946",
                                   "P04179",
                                   "P15559",
                                   "Q7Z5A7",
                                   "Q02297",
                                   "O95168",
                                   "O43181",
                                   "P28799")
res_gmm$symbol[query_miss] <- c("TAFA3",
                                "HBEGF",
                                NA,
                                "ANTKMT",
                                "NAT14",
                                "TNF",
                                "CCL23",
                                "AMY1A",
                                "VEGFA",
                                "LYN B",
                                "ROR1",
                                "DEPP1",
                                NA,
                                "DHX58",
                                "SCN2B",
                                "CRH",
                                NA,
                                "TRH",
                                "DNAJC30",
                                "APOB",
                                "FUT8",
                                "PLA2G1B",
                                "F10",
                                "CARHSP1",
                                NA,
                                NA,
                                "TGFB2",
                                "LARGE1",
                                NA,
                                "FUT10",
                                "FAM241B",
                                NA,
                                "NDUFB8",
                                "GOLM2",
                                "FAM234B",
                                "EREG",
                                "IL16",
                                NA,
                                "NPPB",
                                "BPNT2",
                                "PKD1L1-AS1",
                                "APBB1",
                                "EGF",
                                "CALCA",
                                "IGHE",
                                NA,
                                "AIRC",
                                "IGKV1-5",
                                "ISCU",
                                "APOE2",
                                "SPACA7",
                                NA,
                                NA,
                                "EIF2B1",
                                "ELAPOR1",
                                NA,
                                "PCBP1",
                                "TAFA2",
                                "MUTYH",
                                "FUT3",
                                "CSAG1",
                                NA,
                                "RNPC3",
                                "ENDOU",
                                "PLPP4",
                                "VEGF121",
                                "INS",
                                "SLC66A1LP",
                                "B3GNT3",
                                "TIE1",
                                "PLOD3",
                                "NDUFAF8",
                                NA,
                                "ELAPOR2",
                                "FHIT",
                                "TAFA4",
                                NA,
                                NA,
                                NA,
                                "CLPB",
                                NA,
                                "CDK5R1",
                                "ADM",
                                "SNORC",
                                NA,
                                "ADGRE5",
                                "MYSM1",
                                "FAM107A",
                                "NUDT8",
                                "GSKIP",
                                "SPRING1",
                                "ADA2",
                                "GATD3",
                                "ABRAXAS2",
                                NA,
                                "GNAI3",
                                "NR4A1",
                                "RPS4X",
                                "PPBP",
                                NA,
                                "HPGD",
                                NA,
                                "PDK2",
                                "MINAR1",
                                NA,
                                "SOD3",
                                "EDA",
                                "CBR1",
                                "AGER",
                                "PLG",
                                "RIGI",
                                "PAK5",
                                "APOE3",
                                "FUT9",
                                NA,
                                NA,
                                NA,
                                "METTL1",
                                NA,
                                "PDE4D",
                                "NT5C",
                                "DEFB118",
                                "FMR1",
                                "N-CAM 120",
                                NA,
                                NA,
                                NA,
                                "AKR1A1",
                                "UPK3BL1",
                                "SORBS3",
                                "B3GNT6",
                                "GET3",
                                "PSG7",
                                "IGNT3",
                                "AIMP1",
                                "APBB3",
                                "PDK1",
                                "ENTREP1",
                                "NRG4",
                                "APP",
                                "TGFA",
                                NA,
                                "APBB2",
                                NA,
                                NA,
                                "REPIN1",
                                "NQO2",
                                NA,
                                "USB1",
                                NA,
                                "TGFB3",
                                "TSR3",
                                "DIMT1",
                                NA,
                                "CLEC11A",
                                "MRE11",
                                "PARP1",
                                "GCG",
                                "UBB",
                                "TEX29",
                                "DUSP13A",
                                "CNOT9",
                                "PDE1A",
                                "PDE3A",
                                "SGF29",
                                NA,
                                "C1orf115",
                                "RETREG1",
                                "ESS2",
                                "PARP16",
                                "FGF-8A",
                                "RIDA",
                                "CTSH",
                                "SHISAL2B",
                                "LRP1",
                                "GPR135",
                                NA,
                                "KMT5C",
                                NA,
                                "PARK7",
                                "ALKAL2",
                                "PROC",
                                "JUN",
                                NA,
                                "ST8SIA3",
                                "NDUFB11",
                                "FASLG",
                                NA,
                                "LPAL2",
                                "APEX1",
                                "NUDT12",
                                "RGMB",
                                "TGFB1",
                                "PPIL2",
                                "CBR3",
                                NA,
                                "NPPA",
                                "ASMTL",
                                "FGF-8B",
                                NA,
                                "PXDNL",
                                "NDUFV2",
                                "PRKCB2",
                                "PARP11",
                                "COL18A1",
                                "LCT",
                                "CGK1-beta",
                                "POMC",
                                "FUT5",
                                "PUF60",
                                "SLC9B2",
                                NA,
                                "TEK",
                                "MXRA8",
                                "SST",
                                NA,
                                "TCN2",
                                "PUS1",
                                NA,
                                "PDE7A",
                                "SOD2",
                                "NQO1",
                                "TAFA5",
                                "NRG1",
                                "NDUFB4",
                                "NDUFS4",
                                "GRN")
write.table(res_gmm, "AllResAnno.txt", sep = "\t", quote = F, row.names = F, col.names = T)

res_gmm <- readr::read_delim("AllResAnno.txt", delim = "\t")
res_gmm$pvalue <- 10^(-res_gmm$Negative.log.p)
res_gmm$k <- 1:nrow(res_gmm)
res_gmm_sig <- res_gmm[max(which(res_gmm$pvalue > 0.05/(nrow(res_gmm) + 1 - res_gmm$k))):nrow(res_gmm), ]

api_key <- "621948d3-bc7f-4917-9e06-da7240cb5781"
Sys.setenv(DISGENET_API_KEY= api_key)
res <- disease2evidence(disease = c("UMLS_C0010068", "UMLS_C0007222", "UMLS_C0018801", "UMLS_C0027051"),
                    score = c(0.4,1) 
)



net_res <- read.csv("PPInetwork.csv")
net_res <- net_res %>% arrange(desc(Degree), desc(abs(Expression)))
gene_id <- bitr(net_res$Label, fromType="SYMBOL", toType="ENTREZID", OrgDb="org.Hs.eg.db")
gene_id$SYMBOL[which(!(gene_id$SYMBOL %in% res_gmm$symbol))]
res_gmm$symbol[which(res_gmm$exposure=="Heat shock protein HSP 90-alpha/beta")] <- "HSP90AA1"
for (i in 1:nrow(net_res)) {
  if (net_res$Label[i]%in%res_gmm$symbol){
    net_res$Expression[i] <- (sign(res_gmm$estimate)*log(abs(res_gmm$estimate/res_gmm$se)))[which(res_gmm$symbol==net_res$Label[i])]
  } else {
    net_res$Expression[i] <- 0
  }
}
geneList <- net_res$Expression
names(geneList) <- net_res$Label
# KEGG_results <- enrichKEGG(gene = gene_id$ENTREZID,
#                            organism     = 'hsa',
#                            pAdjustMethod = "holm", 
#                            pvalueCutoff = 0.05,
#                            minGSSize = 10)
# png("fig5c.png",width = 3000, height = 1500, res = 300)
# barplot(KEGG_results) + 
#   theme(plot.title = element_text(hjust = 0.5, face = "bold"))
# dev.off()

EGO_results <- enrichGO(gene = gene_id$ENTREZID,
                        OrgDb    = org.Hs.eg.db,
                        ont = "BP",
                        pvalueCutoff = 0.05, 
                        pAdjustMethod = "holm", 
                        minGSSize = 10,
                        readable = T)
png("fig5c.png",width = 3000, height = 1500, res = 300)
barplot(EGO_results) + ggtitle("GO enrichment analysis") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.text.y = element_text(face = "bold"))
dev.off()

png("figS10.png",width = 8000, height = 6000, res = 300)
heatplot(EGO_results,foldChange = geneList, showCategory = 20) +
  scale_fill_gradient2(low="aquamarine", mid="white", high="lightpink", midpoint=0) +
  theme(axis.text.x = element_text(size = 20, face = "bold"),
        axis.text.y = element_text(size = 20, face = "bold"),
        legend.title = element_text(size = 20, face = "bold"),
        legend.text = element_text(size = 20, face = "bold"))
dev.off()

HDO_results <- enrichDO(gene = gene_id$ENTREZID, 
                        ont = "HDO", 
                        organism = "hsa", 
                        pvalueCutoff = 0.05, 
                        pAdjustMethod = "holm", 
                        minGSSize = 10,
                        readable = T)
png("fig5d.png",width = 3000, height = 1500, res = 300)
barplot(HDO_results, title = "DO enrichment analysis") + 
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.text.y = element_text(face = "bold"))
dev.off()
heatplot(HDO_results,foldChange = geneList) +
  scale_fill_gradient2(low="aquamarine", mid="white", high="lightpink", midpoint=0)

png("figS11.png",width = 8000, height = 6000, res = 300)
heatplot(HDO_results,foldChange = geneList, showCategory = 20) +
  scale_fill_gradient2(low="aquamarine", mid="white", high="lightpink", midpoint=0) +
  theme(axis.text.x = element_text(size = 20, face = "bold"),
        axis.text.y = element_text(size = 20, face = "bold"),
        legend.title = element_text(size = 20, face = "bold"),
        legend.text = element_text(size = 20, face = "bold"))
dev.off()

## Tables

library(knitr)
library(kableExtra)
res_gmm <- readr::read_delim("AllResAnno.txt", delim = "\t")
res_gmm$pvalue <- 10^(-res_gmm$Negative.log.p)
res_gmm$k <- 1:nrow(res_gmm)
res_gmm_sig <- res_gmm[max(which(res_gmm$pvalue > 0.05/(nrow(res_gmm) + 1 - res_gmm$k))):nrow(res_gmm), c(-2, -5, -6, -7, -8, -9, -11, -ncol(res_gmm))]
res_gmm_sig <- res_gmm_sig %>%
  arrange(id.exposure)
kbl(res_gmm_sig, booktabs = T,format = "latex", digits = 3,  col.names = c("Exposure ID", "Estimate", "SE", "Uniprot Accession", "Gene Symbol", "P-value")) %>%
  kable_styling(latex_options = c("scale_down", "hold_position"))
