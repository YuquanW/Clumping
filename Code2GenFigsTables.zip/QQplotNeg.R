library(dplyr)
library(ggplot2)
library(ggpubr)
library(stringr)
filelist <- c("divw.txt",
              "mregger.txt",
              "wme.txt",
              "raps.txt",
              "mrcml.txt",
              "mrapss.txt",
              "mrgmm.txt")
Method <- c("DIVW", "MR-Egger", "WME", "APS", "cML-MA-BIC","MR-APSS","MR-GMM")
prefix <- c("Negative0.05/", "Negative0.1/", "NegativeTop50/", "NegativeTop500/")
title <- paste("Threshold for IV selection:", 
               c("p-value < 0.05",
                 "p-value < 0.1",
                 "smallest 50 p-values",
                 "smallest 500 p-values"))
figname <- paste("fig4", c("a", "b", "c", "d"), ".png", sep = "")

for (j in 1:length(prefix)) {
  res <- NULL
  inflation <- NULL
  for (i in 1:length(filelist)) {
    res_i <- read.table(paste(prefix[j], filelist[i], sep = ""), sep = "\t", header = T, quote = "", row.names = NULL)[, -1]
    #res_i <- res_i[!duplicated(res_i$exposure), ]
    method <- Method[i]
    exp.x <- -log10(rev(ppoints(nrow(res_i))))
    res <- rbind(res, data.frame(id.exposure = res_i$id.exposure,
                                 exposure = res_i$exposure,
                                 estimate = res_i$est,
                                 se = res_i$se,
                                 `Negative log p` = sort(res_i$log_pval),
                                 Theoretical = exp.x,
                                 Method = method,
                                 lower = rev(-log10(qbeta(0.975, seq_len(length(exp.x)), rev(seq_len(length(exp.x)))))),
                                 upper = rev(-log10(qbeta(0.025, seq_len(length(exp.x)), rev(seq_len(length(exp.x))))))))
    inflation <- rbind(inflation, data.frame(chisq = (res_i$est/res_i$se)^2,
                                             method = method))
  }
  res$Method <- factor(res$Method, levels = unique(res$Method))
  inflation$method <- factor(inflation$method, levels = unique(inflation$method))
  inflation <- inflation %>%
    group_by(method) %>%
    summarise(lambda_gc = median(chisq)/qchisq(0.5, 1))
  label <- list(substitute(lambda[DIVW] == value, list(value = sprintf("%.2f", inflation$lambda_gc[1]))),
                substitute(lambda[MR-Egger] == value, list(value = sprintf("%.2f", inflation$lambda_gc[2]))),
                substitute(lambda[WME] == value, list(value = sprintf("%.2f", inflation$lambda_gc[3]))),
                substitute(lambda[APS] == value, list(value = sprintf("%.2f", inflation$lambda_gc[4]))),
                substitute(lambda[cML-MA-BIC] == value, list(value = sprintf("%.2f", inflation$lambda_gc[5]))),
                substitute(lambda[MR-APSS] == value, list(value = sprintf("%.2f", inflation$lambda_gc[6]))),
                substitute(lambda[MR-GMM] == value, list(value = sprintf("%.2f", inflation$lambda_gc[7]))))
  inflation_text <- data.frame(x = 0, y = seq(4, length.out=7, by = -0.3),
                               label = unlist(Map(deparse, label)), 
                               method = factor(Method, levels = Method))
  p <- ggplot(aes(x = Theoretical, y = Negative.log.p, shape = Method, color = Method), data = res) + 
    geom_point(size = 4)+
    ylim(c(0, 4)) +
    geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed", linewidth = 1.5) +
    geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.1, show.legend = F) +
    theme_pubr(base_size = 22) +
    scale_shape_manual(values=seq(12,19)) +
    labs(subtitle = title[j],
         x = expression("Theoretical " * -log[10] *"p"),
         y = expression("Observed " * -log[10] * "p")) +
    theme(plot.subtitle = element_text(size = 18, face = "bold", hjust = 0.5)) +
    geom_text(aes(x = x, y = y, label = label, color = method), data = inflation_text,
              parse = T, hjust = 0, size = 7, show.legend = F)
  p <- ggpar(p, legend = "bottom")
  ggexport(p, filename = figname[j], width = 3000, height = 3000, res = 300)
  
}

  
