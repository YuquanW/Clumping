library(ggplot2)
library(ggpubr)
library(dplyr)
bmi.bmi.sigma <- read.table("./Identity/BMI-BMI.sigma.txt", sep = "\t", row.names = NULL)[, -1]
bmi.bmi.sigma$Method <- factor(bmi.bmi.sigma$method, levels = unique(bmi.bmi.sigma$method))
bmi.bmi.sigma <- bmi.bmi.sigma %>%
  arrange(desc(Method))
bmi.bmi.sigma$index <- 1:56
p <- ggplot(bmi.bmi.sigma, aes(x = beta, y = factor(index), group = Method)) +
  geom_point(aes(shape = Method, color = Method), size = 4) +  # Add points for effect sizes
  geom_errorbarh(aes(xmin = ci.lower, xmax = ci.upper, color = Method), height = 1, linewidth = 1) +  # Add error bars
  geom_vline(xintercept = 1, linetype = "dashed", color = "red") +  # Reference line at 1 (no effect)
  labs(
    x = "Effect Size",
    y = "Threshold"
  ) +
  theme_pubr(base_size = 22) +
  scale_shape_manual(values = seq(12, 18)) +
  scale_y_discrete(breaks = 1:56,
                   labels = rep(c(paste("5e-", 8:2, sep = ""), "1"), 7))
ggexport(p,filename = "fig3a.png", width = 3000, height = 5000, res = 300)

bmi.bmi.pvalue <- read.table("./Identity/BMI-BMI.pvalue.txt", sep = "\t", row.names = NULL)[, -1]
bmi.bmi.pvalue$Method <- factor(bmi.bmi.pvalue$method, levels = unique(bmi.bmi.pvalue$method))
bmi.bmi.pvalue <- bmi.bmi.pvalue %>%
  arrange(desc(Method))
bmi.bmi.pvalue$index <- 1:56
p <- ggplot(bmi.bmi.pvalue, aes(x = beta, y = factor(index), group = Method)) +
  geom_point(aes(shape = Method, color = Method), size = 4) +  # Add points for effect sizes
  geom_errorbarh(aes(xmin = ci.lower, xmax = ci.upper, color = Method), height = 1, linewidth = 1) +  # Add error bars
  geom_vline(xintercept = 1, linetype = "dashed", color = "red") +  # Reference line at 1 (no effect)
  labs(
    x = "Effect Size",
    y = "Threshold"
  ) +
  theme_pubr(base_size = 22) +
  scale_shape_manual(values = seq(12, 18)) +
  scale_y_discrete(breaks = 1:56,
                   labels = rep(c(paste("5e-", 8:2, sep = ""), "1"), 7))
ggexport(p,filename = "fig3b.png", width = 3000, height = 5000, res = 300)

hdl.hdl.sigma <- read.table("./Identity/HDL-HDL.sigma.txt", sep = "\t", row.names = NULL)[, -1]
hdl.hdl.sigma$Method <- factor(hdl.hdl.sigma$method, levels = unique(hdl.hdl.sigma$method))
hdl.hdl.sigma <- hdl.hdl.sigma %>%
  arrange(desc(Method))
hdl.hdl.sigma$index <- 1:56
p <- ggplot(hdl.hdl.sigma, aes(x = beta, y = factor(index), group = Method)) +
  geom_point(aes(shape = Method, color = Method), size = 4) +  # Add points for effect sizes
  geom_errorbarh(aes(xmin = ci.lower, xmax = ci.upper, color = Method), height = 1, linewidth = 1) +  # Add error bars
  geom_vline(xintercept = 1, linetype = "dashed", color = "red") +  # Reference line at 1 (no effect)
  labs(
    x = "Effect Size",
    y = "Threshold"
  ) +
  theme_pubr(base_size = 22) +
  scale_shape_manual(values = seq(12, 18)) +
  scale_y_discrete(breaks = 1:56,
                   labels = rep(c(paste("5e-", 8:2, sep = ""), "1"), 7))
ggexport(p,filename = "figS2a.png", width = 3000, height = 5000, res = 300)

hdl.hdl.pvalue <- read.table("./Identity/HDL-HDL.pvalue.txt", sep = "\t", row.names = NULL)[, -1]
hdl.hdl.pvalue$Method <- factor(hdl.hdl.pvalue$method, levels = unique(hdl.hdl.pvalue$method))
hdl.hdl.pvalue <- hdl.hdl.pvalue %>%
  arrange(desc(Method))
hdl.hdl.pvalue$index <- 1:56
p <- ggplot(hdl.hdl.pvalue, aes(x = beta, y = factor(index), group = Method)) +
  geom_point(aes(shape = Method, color = Method), size = 4) +  # Add points for effect sizes
  geom_errorbarh(aes(xmin = ci.lower, xmax = ci.upper, color = Method), height = 1, linewidth = 1) +  # Add error bars
  geom_vline(xintercept = 1, linetype = "dashed", color = "red") +  # Reference line at 1 (no effect)
  labs(
    x = "Effect Size",
    y = "Threshold"
  ) +
  theme_pubr(base_size = 22) +
  scale_shape_manual(values = seq(12, 18)) +
  scale_y_discrete(breaks = 1:56,
                   labels = rep(c(paste("5e-", 8:2, sep = ""), "1"), 7))
ggexport(p,filename = "figS2b.png", width = 3000, height = 5000, res = 300)
