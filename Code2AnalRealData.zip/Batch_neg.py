# -*- coding: utf-8 -*-
"""
Created on Thu Oct 31 16:22:54 2024

@author: 22137
"""
start = list(range(1, 1202, 40))
stop = list(range(40, 1241, 40))

for i in range(len(start)):
    script_name = f'cleanbatch{i}.sh'
    with open(script_name, 'w') as f:
        f.write(r'''#!/bin/bash
for i in {''' + str(start[i]) + r'''..''' + str(stop[i]) + r'''}; do
input_file=/vdata/Shidp/Proteom/Negative/ieu-a-$i.vcf.gz
output_file=/vdata/Shidp/Proteom/Negative/ieu-a-$i.exposure.stan.txt
outcome_file=/vdata/Shidp/Proteom/Negative/ieu-a-$i.outcome.stan.txt

# Check if the input file exists
if [[ -f $input_file ]]; then
    echo "Processing $input_file..."
    # Use bcftools query to extract the CHROM field
    bcftools isec -n=2 -c all -p /vdata/Shidp/Proteom/Negative/common$i $input_file /vdata/Shidp/Proteom/Negative/ukb-d-1747_1.vcf.gz
    bcftools norm -m+ /vdata/Shidp/Proteom/Negative/common$i/0001.vcf -o /vdata/Shidp/Proteom/Negative/common$i/tmp.vcf
    awk '/#/{print;next}{if($5 !~ /,/ && length($5)==1 && length($4)==1){print}}' /vdata/Shidp/Proteom/Negative/common$i/tmp.vcf > /vdata/Shidp/Proteom/Negative/common$i/tmp1.vcf
    awk '/#/{print;next}{if(!($4 ~ /A/ && $5 ~ /T/) && !($4 ~ /T/ && $5 ~ /A/) && !($4 ~ /G/ && $5 ~ /C/) && !($4 ~ /C/ && $5 ~ /G/)){print}}' /vdata/Shidp/Proteom/Negative/common$i/tmp1.vcf > /vdata/Shidp/Proteom/Negative/common$i/tmp.vcf
    bcftools view -i'FMT/AF > 0.01 & FMT/AF < 0.99' /vdata/Shidp/Proteom/Negative/common$i/tmp.vcf -o /vdata/Shidp/Proteom/Negative/common$i/Outcome.vcf
    python ~/wyq/GMM/RealData/extract_snps.py -i /vdata/Shidp/Proteom/Negative/common$i/0000.vcf -r /vdata/Shidp/Proteom/Negative/common$i/Outcome.vcf -o /vdata/Shidp/Proteom/Negative/common$i/Exposure.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%LP\t%SE]\n' /vdata/Shidp/Proteom/Negative/common$i/Exposure.vcf -o /vdata/Shidp/Proteom/Negative/common$i/clump-1.txt
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%LP\t%SE]\n' /vdata/Shidp/Proteom/Negative/common$i/Outcome.vcf -o /vdata/Shidp/Proteom/Negative/common$i/clump-2.txt
    awk 'NR==FNR{C2[NR]=$NF; next} {PS = 1/(1/$NF^2 + 1/C2[FNR]^2); NF--; OFS="\t"; print $1, $2, $3, $4, $5, $6, PS}' /vdata/Shidp/Proteom/Negative/common$i/clump-2.txt /vdata/Shidp/Proteom/Negative/common$i/clump-1.txt > /vdata/Shidp/Proteom/Negative/common$i/clump.txt
    awk 'BEGIN {threshold = 3.30} $6 > threshold' /vdata/Shidp/Proteom/Negative/common$i/clump.txt > /vdata/Shidp/Proteom/Negative/common$i/clump_filtered.txt
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.exposure\teffect_allele.exposure\tpval.exposure\tP\n/' /vdata/Shidp/Proteom/Negative/common$i/clump_filtered.txt
    ~/wyq/GMM/RealData/plink2 --bfile ~/wyq/GMM/RealData/1000Genomes/1000G.EUR.QC.ALL --clump /vdata/Shidp/Proteom/Negative/common$i/clump_filtered.txt --clump-p1 1 --clump-p2 1 --clump-r2 0.001 --clump-kb 10000 --out /vdata/Shidp/Proteom/Negative/common$i/filtered
    bcftools view -R /vdata/Shidp/Proteom/Negative/common$i/filtered.clumps $input_file -o /vdata/Shidp/Proteom/Negative/common$i/clumped.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%ES\t%SE\t%LP\t%AF\t%SS]\n' /vdata/Shidp/Proteom/Negative/common$i/clumped.vcf -o $output_file
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.exposure\teffect_allele.exposure\tbeta.exposure\tse.exposure\tpval.exposure\teaf.exposure\tsamplesize.exposure\n/' $output_file
    bcftools view -R /vdata/Shidp/Proteom/Negative/common$i/filtered.clumps /vdata/Shidp/Proteom/Negative/ukb-d-1747_1.vcf.gz -o /vdata/Shidp/Proteom/Negative/common$i/clumped.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%ES\t%SE\t%LP\t%AF\t%SS]\n' /vdata/Shidp/Proteom/Negative/common$i/clumped.vcf -o $outcome_file
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.outcome\teffect_allele.outcome\tbeta.outcome\tse.outcome\tpval.outcome\teaf.outcome\tsamplesize.outcome\n/' $outcome_file

    rm -rf /vdata/Shidp/Proteom/Negative/common$i/
    echo "Output saved to $output_file."
else
    echo "File $input_file does not exist. Skipping..."
fi
done''')

for i in range(len(start)):
    script_name = f'cleanbatch{i}.slurm'
    with open(script_name, 'w') as f:
        f.write(r'''#!/bin/bash
#SBATCH -J Batch''' + str(i) + r'''
#SBATCH -o Batch''' + str(i) + r'''.out
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -w node2

# 记录程序启动时间
start_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "程序启动时间：$start_time"

bash ./cleanbatch''' + str(i) + r'''.sh > cleanbatch''' + str(i) + r'''.log 2>&1

# 记录程序结束时间
end_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "程序结束时间：$end_time"

# 计算总运行时间（以分钟为单位）
start_seconds=$(date -d "$start_time" +%s)
end_seconds=$(date -d "$end_time" +%s)
total_seconds=$((end_seconds - start_seconds))
total_minutes=$((total_seconds / 60))
echo "程序总运行时间（分钟）：$total_minutes 分钟"''')