# -*- coding: utf-8 -*-
"""
Created on Thu Oct 31 16:22:54 2024

@author: 22137
"""
start = list(range(1, 3202, 100))
stop = list(range(100, 3301, 100))

for i in range(len(start)):
    script_name = f'cleanbatch{i}.sh'
    with open(script_name, 'w') as f:
        f.write(r'''#!/bin/bash
for i in {''' + str(start[i]) + r'''..''' + str(stop[i]) + r'''}; do
input_file=/vdata/Shidp/Proteom/Exposure/prot-a-$i.vcf.gz
output_file=/vdata/Shidp/Proteom/Outcome/prot-a-$i.exposure.txt
outcome_file=/vdata/Shidp/Proteom/Outcome/prot-a-$i.outcome.txt

# Check if the input file exists
if [[ -f $input_file ]]; then
    echo "Processing $input_file..."
    # Use bcftools query to extract the CHROM field
    bcftools isec -n=2 -c all -p ./Identification/common$i $input_file /vdata/Shidp/Proteom/Outcome/ieu-a-7.vcf.gz
    bcftools norm -m+ ./Identification/common$i/0000.vcf -o ./Identification/common$i/tmp.vcf
    awk '/#/{print;next}{if($5 !~ /,/ && length($5)==1 && length($4)==1){print}}' ./Identification/common$i/tmp.vcf > ./Identification/common$i/tmp1.vcf
    awk '/#/{print;next}{if(!($4 ~ /A/ && $5 ~ /T/) && !($4 ~ /T/ && $5 ~ /A/) && !($4 ~ /G/ && $5 ~ /C/) && !($4 ~ /C/ && $5 ~ /G/)){print}}' ./Identification/common$i/tmp1.vcf > ./Identification/common$i/tmp.vcf
    bcftools view -i'FMT/AF > 0.01 & FMT/AF < 0.99' ./Identification/common$i/tmp.vcf -o ./Identification/common$i/Exposure.vcf
    python extract_snps.py -i ./Identification/common$i/0001.vcf -r ./Identification/common$i/Exposure.vcf -o ./Identification/common$i/Outcome.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%LP\t%SE]\n' ./Identification/common$i/Exposure.vcf -o ./Identification/common$i/clump-1.txt
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%LP\t%SE]\n' ./Identification/common$i/Outcome.vcf -o ./Identification/common$i/clump-2.txt
    awk 'NR==FNR{C2[NR]=$NF; next} {PS = 1/(1/$NF^2 + 1/C2[FNR]^2); NF--; OFS="\t"; print $1, $2, $3, $4, $5, $6, PS}' ./Identification/common$i/clump-2.txt ./Identification/common$i/clump-1.txt > ./Identification/common$i/clump.txt
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.exposure\teffect_allele.exposure\tpval.exposure\tP\n/' ./Identification/common$i/clump.txt
    ./plink2 --bfile ./1000Genomes/1000G.EUR.QC.ALL --clump ./Identification/common$i/clump.txt --clump-p1 1 --clump-p2 1 --clump-r2 0.001 --clump-kb 10000 --out ./Identification/common$i/filtered
    bcftools view -R ./Identification/common$i/filtered.clumps $input_file -o ./Identification/common$i/clumped.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%ES\t%SE\t%LP\t%AF\t%SS]\n' ./Identification/common$i/clumped.vcf -o $output_file
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.exposure\teffect_allele.exposure\tbeta.exposure\tse.exposure\tpval.exposure\teaf.exposure\tsamplesize.exposure\n/' $output_file
    bcftools view -R ./Identification/common$i/filtered.clumps /vdata/Shidp/Proteom/Outcome/ieu-a-7.vcf.gz -o ./Identification/common$i/clumped.vcf
    bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT[\t%ES\t%SE\t%LP\t%AF\t%SS]\n' ./Identification/common$i/clumped.vcf -o $outcome_file
    sed -i '1s/^/CHR\tPOS\tSNP\tother_allele.outcome\teffect_allele.outcome\tbeta.outcome\tse.outcome\tpval.outcome\teaf.outcome\tsamplesize.outcome\n/' $outcome_file

    rm -rf ./Identification/common$i/
    echo "Output saved to $output_file."
else
    echo "File $input_file does not exist. Skipping..."
fi
done''')

for i in range(len(start)):
    script_name = f'cleanbatch{i}.slurm'
    with open(script_name, 'w') as f:
        f.write(r'''#!/bin/bash
#SBATCH -J Batch''' + str(i) + r'''
#SBATCH -o Batch''' + str(i) + r'''.out
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -w node3

# 记录程序启动时间
start_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "程序启动时间：$start_time"

bash $HOME/wyq/GMM/RealData/cleanbatch''' + str(i) + r'''.sh > cleanbatch''' + str(i) + r'''.log 2>&1

# 记录程序结束时间
end_time=$(date +"%Y-%m-%d %H:%M:%S")
echo "程序结束时间：$end_time"

# 计算总运行时间（以分钟为单位）
start_seconds=$(date -d "$start_time" +%s)
end_seconds=$(date -d "$end_time" +%s)
total_seconds=$((end_seconds - start_seconds))
total_minutes=$((total_seconds / 60))
echo "程序总运行时间（分钟）：$total_minutes 分钟"''')